plugins { id("com.android.application") }
android {
    namespace = "com.mohammed.siraj"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mohammed.siraj"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "6.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { implementation("androidx.webkit:webkit:1.11.0") }
