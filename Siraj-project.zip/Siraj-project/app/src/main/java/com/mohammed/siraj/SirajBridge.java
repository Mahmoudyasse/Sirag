package com.mohammed.siraj;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;

/** الجسر القديم اللي صفحة سراج بتستخدمه (إشعارات + مواقيت الأذان) */
public class SirajBridge {
    final Activity act;
    SirajBridge(Activity a) { act = a; }
    @JavascriptInterface public void notify(String tag, String title, String body) { SirajReceivers.show(act, title, body, false); }
    @JavascriptInterface public boolean hasPermission() { return Build.VERSION.SDK_INT < 33 || act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED; }
    @JavascriptInterface public void requestPermission() { ((MainActivity) act).askNotif(); }
    @JavascriptInterface public int takeTaps() { return 0; }
    @JavascriptInterface public void sync(String json) {}
    @JavascriptInterface public void setAlarms(String json) {
        try {
            JSONArray in = new JSONArray(json), out = new JSONArray();
            for (int i = 0; i < in.length(); i++) {
                JSONObject o = in.getJSONObject(i), n = new JSONObject();
                n.put("id", "adhan" + (long) o.getDouble("t")); n.put("t", o.getDouble("t")); n.put("title", "سراج"); n.put("body", "حان وقت صلاة " + o.getString("n"));
                out.put(n);
            }
            SirajMedia.doSchedule(act, "adhan", out);
        } catch (Exception ignored) {}
    }

    /** تحميل سورة على الفون (مجلد التنزيلات/Siraj) عن طريق DownloadManager */
    @JavascriptInterface public String saveAudio(String url, String name) {
        try {
            if (Build.VERSION.SDK_INT < 29 && act.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
                return "perm";
            }
            if (url == null || !url.startsWith("http")) return "err";
            String safe = (name == null || name.isEmpty()) ? "siraj.mp3" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
            android.app.DownloadManager.Request r = new android.app.DownloadManager.Request(android.net.Uri.parse(url));
            r.setTitle(safe);
            r.setDescription("سراج");
            r.setMimeType("audio/mpeg");
            r.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "Siraj/" + safe);
            ((android.app.DownloadManager) act.getSystemService(android.content.Context.DOWNLOAD_SERVICE)).enqueue(r);
            return "ok";
        } catch (Exception e) { return "err"; }
    }
}
