package com.mohammed.siraj;

import android.app.*;
import android.content.*;
import android.graphics.drawable.Icon;
import android.os.*;

/** إشعار دائم برّا التطبيق: الصلاة القادمة (عدّاد تنازلي) + تحكم القرآن (تقليب يمين/شمال وتشغيل/إيقاف) */
public class SirajService extends Service {
    static SirajService instance;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable tick = new Runnable() { public void run() {
        IosWidgets.updateRamadan(SirajService.this);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        h.postDelayed(this, pm.isInteractive() ? 1000 : 60000);
    } };

    @Override public void onCreate() {
        super.onCreate(); instance = this;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("siraj_live", "سراج (دائم)", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false); nm.createNotificationChannel(c);
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, build());
        h.post(tick);
    }

    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onDestroy() { instance = null; h.removeCallbacks(tick); super.onDestroy(); }

    void refresh() { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(1, build()); }

    private Notification.Action act(String a, int icon, String label) {
        PendingIntent p = PendingIntent.getBroadcast(this, a.hashCode(), new Intent(this, SirajReceivers.Media.class).setAction("siraj.media." + a), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), label, p).build();
    }

    Notification build() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "siraj_live") : new Notification.Builder(this);
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        b.setSmallIcon(R.drawable.ic_notif).setOngoing(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PUBLIC)
         .setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE));
        String next = SirajMedia.nextName.isEmpty() ? "" : "الصلاة القادمة: " + SirajMedia.nextName;
        if (SirajMedia.nextMs > System.currentTimeMillis()) {
            b.setWhen(SirajMedia.nextMs).setShowWhen(true).setUsesChronometer(true);
            if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true);
        }
        if (SirajMedia.hasMedia) {
            b.setContentTitle(SirajMedia.title).setContentText(SirajMedia.reader.isEmpty() ? next : SirajMedia.reader + " · " + next);
            b.addAction(act("prev", android.R.drawable.ic_media_previous, "السابق"));
            b.addAction(act("toggle", SirajMedia.playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, "تشغيل/إيقاف"));
            b.addAction(act("next", android.R.drawable.ic_media_next, "التالي"));
            b.setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        } else b.setContentTitle("سراج").setContentText(next.isEmpty() ? "يعمل في الخلفية" : next);
        return b.build();
    }
}
