package com.mohammed.siraj;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

/** جسر الجافاسكربت: addJavascriptInterface(new SirajMedia(this, webView), "SirajMedia") */
public class SirajMedia {
    static WebView web;
    static String title = "", reader = "", nextName = "";
    static boolean playing = false, hasMedia = false;
    static long nextMs = 0;
    final Context ctx;

    public SirajMedia(Context c, WebView w) {
        ctx = c.getApplicationContext();
        web = w;
        Intent i = new Intent(ctx, SirajService.class);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    static void js(final String code) {
        final WebView w = web;
        if (w != null) w.post(new Runnable() { public void run() { w.evaluateJavascript(code, null); } });
    }

    static void refresh() { SirajService s = SirajService.instance; if (s != null) s.refresh(); }

    @JavascriptInterface public void update(String t, String r, boolean p) { title = t; reader = r; playing = p; hasMedia = true; refresh(); }
    @JavascriptInterface public void setNext(String n, double ms) { nextName = n; nextMs = (long) ms; refresh(); IosWidgets.updateAll(ctx); }
    @JavascriptInterface public void setWidget(String json) {
        ctx.getSharedPreferences("siraj_w", 0).edit().putString("cfg", json).apply();
        IosWidgets.updateAll(ctx);
    }

    @JavascriptInterface public void schedule(String json) { try { doSchedule(ctx, "alerts", new JSONArray(json)); } catch (Exception ignored) {} }

    static void doSchedule(Context ctx, String key, JSONArray a) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences sp = ctx.getSharedPreferences("siraj_s", 0);
            for (String id : sp.getStringSet("ids_" + key, new HashSet<String>())) am.cancel(pi(ctx, id, "", "", false, PendingIntent.FLAG_UPDATE_CURRENT));
            Set<String> ids = new HashSet<String>();
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String id = key + "_" + o.getString("id");
                PendingIntent p = pi(ctx, id, o.optString("title", "سراج"), o.optString("body"), o.optInt("sal") == 1, PendingIntent.FLAG_UPDATE_CURRENT);
                long t = (long) o.getDouble("t");
                if (t < System.currentTimeMillis()) continue;
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
                ids.add(id);
            }
            sp.edit().putStringSet("ids_" + key, ids).apply();
        } catch (Exception ignored) {}
    }

    static PendingIntent pi(Context ctx, String id, String t, String b, boolean sal, int flag) {
        Intent i = new Intent(ctx, SirajReceivers.Notif.class).putExtra("t", t).putExtra("b", b).putExtra("s", sal);
        i.setAction("siraj.alarm." + id);
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i, flag | PendingIntent.FLAG_IMMUTABLE);
    }
}
