package com.mohammed.siraj;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

public class SirajReceivers {
    /** أزرار الإشعار الدائم: prev / toggle / next */
    public static class Media extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction() == null ? "" : i.getAction();
            SirajMedia.js("window.__sirajMedia&&__sirajMedia('" + a.replace("siraj.media.", "") + "')");
        }
    }

    static void show(Context c, String title, String body, boolean sal) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        String ch = sal ? "siraj_salawat" : "siraj_alerts";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(ch, sal ? "الصلاة على النبي" : "تذكيرات سراج", NotificationManager.IMPORTANCE_HIGH);
            int raw = c.getResources().getIdentifier("salawat", "raw", c.getPackageName());
            if (sal && raw != 0) nc.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + raw),
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            nm.createNotificationChannel(nc);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, ch) : new Notification.Builder(c);
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        b.setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(body).setAutoCancel(true)
         .setContentIntent(PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE));
        nm.notify((int) (System.currentTimeMillis() % 100000) + 100, b.build());
    }

    public static class Notif extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) { show(c, i.getStringExtra("t"), i.getStringExtra("b"), i.getBooleanExtra("s", false)); }
    }
}
