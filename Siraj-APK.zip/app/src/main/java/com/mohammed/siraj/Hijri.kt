package com.mohammed.siraj

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

object Hijri {
    val MONTHS = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )
    val DAYS = arrayOf("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")

    class Parts(val day: Int, val month: Int, val year: Int)

    fun of(d: LocalDate): Parts {
        val h = HijrahDate.from(d)
        return Parts(h.get(ChronoField.DAY_OF_MONTH), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.YEAR))
    }

    class Ram(val inR: Boolean, val day: Int, val daysLeft: Int)

    /** Days until Ramadan (or until Eid when already in Ramadan). */
    fun ramadan(today: LocalDate): Ram {
        val h = of(today)
        val inR = h.month == 9
        var c = 0
        while (c < 400) {
            val y = of(today.plusDays(c.toLong()))
            if (if (inR) (y.month == 10 && y.day == 1) else (y.month == 9 && y.day == 1)) break
            c++
        }
        return Ram(inR, h.day, c)
    }
}
