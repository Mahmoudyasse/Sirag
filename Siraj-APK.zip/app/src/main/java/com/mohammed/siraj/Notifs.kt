package com.mohammed.siraj

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId

/** Notification channels, display, and exact prayer-time alarms. */
object Notifs {
    const val CH_PRAYER = "siraj_prayer"
    const val CH_GENERAL = "siraj_general"
    private const val BASE_CODE = 4000
    private const val MAX = 24

    private fun sp(c: Context) = c.getSharedPreferences("siraj_notifs", Context.MODE_PRIVATE)

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PRAYER, "مواقيت الصلاة", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "تنبيه عند دخول وقت كل صلاة"
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_GENERAL, "تنبيهات سراج", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تنبيهات وتذكيرات عامة"
            }
        )
    }

    fun enabled(ctx: Context): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun idOf(tag: String): Int = tag.hashCode() and 0x7fffffff

    fun show(ctx: Context, tag: String, title: String, body: String, channel: String = CH_GENERAL) {
        if (!enabled(ctx)) return
        try {
            createChannels(ctx)
            val id = idOf(tag)
            val open = PendingIntent.getActivity(
                ctx, id,
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, channel)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .build()
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: Exception) { }
    }

    fun welcomeOnce(ctx: Context) {
        val p = sp(ctx)
        if (p.getBoolean("welcomed", false)) return
        p.edit().putBoolean("welcomed", true).apply()
        show(ctx, "welcome", "سراج", "تم تفعيل الإشعارات، هيوصلك تنبيه عند كل صلاة")
    }

    // ---------- prayer alarms ----------
    private class A(val n: String, val t: Long)

    private fun pi(ctx: Context, code: Int, name: String, at: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, PrayerAlarmReceiver::class.java).putExtra("n", name).putExtra("t", at),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** json: [{"n":"الفجر","t":epochMillis}, ...] computed by the page (includes user offsets). */
    fun setAlarms(ctx: Context, json: String) {
        sp(ctx).edit().putString("list", json).apply()
        reschedule(ctx)
    }

    private fun load(ctx: Context): List<A> = try {
        val arr = JSONArray(sp(ctx).getString("list", "[]"))
        (0 until arr.length()).map { val o = arr.getJSONObject(it); A(o.getString("n"), o.getLong("t")) }
    } catch (e: Exception) { emptyList() }

    /** Used when the app wasn't opened for days: native calc (no manual offsets). */
    private fun fallback(ctx: Context): List<A> {
        val s: JSONObject = Store.snap(ctx)
        val la = s.optDouble("lat", 30.0444)
        val ln = s.optDouble("lng", 31.2357)
        val zone = ZoneId.systemDefault()
        val out = ArrayList<A>()
        for (d in 0..3) {
            val date = LocalDate.now().plusDays(d.toLong())
            val tz = date.atTime(12, 0).atZone(zone).offset.totalSeconds / 3600.0
            val p = Prayer.times(date, tz, la, ln)
            for (i in intArrayOf(0, 2, 3, 4, 5)) {
                val h = p[i]
                if (h.isNaN()) continue
                val t = date.atStartOfDay(zone).plusMinutes(Math.round(h * 60)).toInstant().toEpochMilli()
                if (t > System.currentTimeMillis()) out.add(A(Prayer.NAMES[i], t))
            }
        }
        return out
    }

    fun reschedule(ctx: Context) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            for (i in 0 until MAX) am.cancel(pi(ctx, BASE_CODE + i, "", 0))
            var list = load(ctx).filter { it.t > System.currentTimeMillis() }
            if (list.size < 3) list = fallback(ctx)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            list.sortedBy { it.t }.take(MAX).forEachIndexed { i, a ->
                val p = pi(ctx, BASE_CODE + i, a.n, a.t)
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, a.t, p)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, a.t, p)
            }
        } catch (e: Exception) { }
    }
}

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val n = intent.getStringExtra("n") ?: return
        val t = intent.getLongExtra("t", 0)
        // skip stale deliveries (e.g. phone was off)
        if (t > 0 && System.currentTimeMillis() - t < 20 * 60 * 1000) {
            Notifs.show(ctx, "pr_$n", "سراج", "حان الآن موعد صلاة $n", Notifs.CH_PRAYER)
        }
        Notifs.reschedule(ctx)
    }
}
