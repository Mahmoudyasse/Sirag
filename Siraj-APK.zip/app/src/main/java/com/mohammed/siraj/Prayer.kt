package com.mohammed.siraj

import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.Locale
import kotlin.math.*

/** Same algorithm as PT() inside index.html, so widget == app. */
object Prayer {
    val NAMES = arrayOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")

    fun times(date: LocalDate, tz: Double, la: Double, ln: Double): DoubleArray {
        val r = Math.PI / 180
        val d = date.toEpochDay() + 0.5 + 2440587.5 - 2451545.0
        val g = (357.529 + .98560028 * d) % 360
        val q = (280.459 + .98564736 * d) % 360
        val lm = q + 1.915 * sin(g * r) + .02 * sin(2 * g * r)
        val e = 23.439 - 4e-7 * d
        val ra = ((atan2(cos(e * r) * sin(lm * r), cos(lm * r)) / r / 15) % 24 + 24) % 24
        val de = asin(sin(e * r) * sin(lm * r))
        val eq = q / 15 - ra
        val dh = 12 + tz - ln / 15 - ((((eq + 12) % 24 + 24) % 24) - 12)
        fun t(a: Double) = acos((sin(a * r) - sin(de) * sin(la * r)) / (cos(de) * cos(la * r))) / r / 15
        val asr = atan(1 / (1 + tan(abs(la * r - de)))) / r
        return doubleArrayOf(
            dh - t(-19.5), dh - t(-.833), dh + .02,
            dh + t(asr), dh + t(-.833) + .02, dh + t(-17.5)
        )
    }

    class Next(val name: String, val atMillis: Long, val hours: Double)

    fun next(la: Double, ln: Double, now: ZonedDateTime = ZonedDateTime.now()): Next {
        val today = now.toLocalDate()
        val tz = now.offset.totalSeconds / 3600.0
        val p = times(today, tz, la, ln)
        val c = now.hour + now.minute / 60.0 + now.second / 3600.0
        val start = today.atStartOfDay(now.zone).toInstant().toEpochMilli()
        for (i in 0..5) {
            if (i == 1) continue
            if (p[i] > c) return Next(NAMES[i], start + (p[i] * 3600000).toLong(), p[i])
        }
        return Next(NAMES[0], start + ((p[0] + 24) * 3600000).toLong(), p[0] + 24)
    }

    fun ar(s: String): String = s.map { if (it in '0'..'9') ('٠' + (it - '0')) else it }.joinToString("")

    fun fmt(h0: Double): String {
        val h = ((h0 % 24) + 24) % 24
        val m = Math.round(h * 60).toInt()
        val hh = (m / 60) % 24
        val mm = m % 60
        val h12 = if (hh % 12 == 0) 12 else hh % 12
        return ar(String.format(Locale.US, "%d:%02d", h12, mm)) + if (hh < 12) " ص" else " م"
    }
}
