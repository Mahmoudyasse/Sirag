package com.mohammed.siraj

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.net.HttpURLConnection
import java.net.URL

/**
 * The page is served from https://appassets.androidplatform.net, so fetch()/XHR to other
 * sites (adhan mp3, Quran audio, APIs) fails unless the remote server sends CORS headers.
 * We perform those GET requests natively and add the CORS headers to the response.
 */
object Cors {
    private const val SELF = "appassets.androidplatform.net"

    fun proxy(r: WebResourceRequest): WebResourceResponse? {
        try {
            if (!r.method.equals("GET", true)) return null
            val u = r.url
            if (u.scheme != "http" && u.scheme != "https") return null
            if (u.host == SELF) return null

            val h = r.requestHeaders ?: return null
            val originHdr = h.entries.firstOrNull { it.key.equals("Origin", true) }?.value
            val mode = h.entries.firstOrNull { it.key.equals("Sec-Fetch-Mode", true) }?.value
            val origin: String = originHdr
                ?: (if (mode.equals("cors", true)) "https://$SELF" else return null)

            var url = u.toString()
            var conn: HttpURLConnection? = null
            for (i in 0 until 6) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 20000
                c.readTimeout = 60000
                for ((k, v) in h) {
                    if (k.equals("Origin", true) || k.equals("Referer", true) ||
                        k.equals("Host", true) || k.equals("Accept-Encoding", true)) continue
                    c.setRequestProperty(k, v)
                }
                val code = c.responseCode
                if (code in 301..308) {
                    val loc = c.getHeaderField("Location")
                    c.disconnect()
                    if (loc == null) return null
                    url = URL(URL(url), loc).toString()
                    continue
                }
                conn = c
                break
            }
            val c = conn ?: return null
            val code = c.responseCode
            if (code !in 200..299) { c.disconnect(); return null }

            val ct = c.contentType
            var mime = "application/octet-stream"
            var enc: String? = null
            if (ct != null) {
                mime = ct.substringBefore(';').trim()
                val i = ct.lowercase().indexOf("charset=")
                if (i >= 0) enc = ct.substring(i + 8).trim()
            }
            val rh = HashMap<String, String>()
            rh["Access-Control-Allow-Origin"] = origin
            rh["Access-Control-Allow-Credentials"] = "true"
            rh["Access-Control-Allow-Headers"] = "*"
            rh["Access-Control-Expose-Headers"] = "*"
            c.getHeaderField("Content-Range")?.let { rh["Content-Range"] = it }
            c.getHeaderField("Accept-Ranges")?.let { rh["Accept-Ranges"] = it }

            val reason = c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK"
            return WebResourceResponse(mime, enc, code, reason, rh, c.inputStream)
        } catch (e: Exception) {
            return null
        }
    }
}
