package com.mohammed.siraj

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCb: GeolocationPermissions.Callback? = null
    private var pendingGo: String? = null
    private var loaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = false
            setGeolocationEnabled(true)
        }
        web.addJavascriptInterface(Bridge(applicationContext), "SirajBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) { }
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                loaded = true
                pendingGo?.let { g -> pendingGo = null; goTo(g, 900) }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false)
                } else {
                    geoOrigin = origin; geoCb = callback
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 11
                    )
                }
            }

            override fun onShowFileChooser(
                view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params.createIntent(), 12); true
                } catch (e: Exception) { fileCb = null; false }
            }
        }

        pendingGo = intent?.getStringExtra("go")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val g = intent.getStringExtra("go") ?: return
        if (loaded) goTo(g, 0) else pendingGo = g
    }

    private fun goTo(page: String, delay: Long) {
        val js = "try{go('$page')}catch(e){}"
        web.postDelayed({ web.evaluateJavascript(js, null) }, delay)
    }

    override fun onResume() {
        super.onResume()
        if (loaded) web.evaluateJavascript("window.__sirajPull&&window.__sirajPull()", null)
        Widgets.updateAll(applicationContext)
        Scheduler.schedule(applicationContext)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 11) {
            geoCb?.invoke(geoOrigin, res.any { it == PackageManager.PERMISSION_GRANTED }, false)
            geoCb = null; geoOrigin = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 12) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Mirrors the in-app "رجوع" button: close drawer -> click the screen's back chip -> go home -> exit
        val js = """
            (function(){try{
              var d=document.getElementById('dw');
              if(d&&d.classList.contains('o')){dr();return 1}
              if(typeof cur!=='undefined'&&cur==='wsolo'){go('widgets');return 1}
              var v=document.getElementById('v')||document;
              var bs=[].slice.call(v.querySelectorAll('button.chip,button'));
              for(var i=0;i<bs.length;i++){if(/رجوع/.test(bs[i].textContent)){bs[i].click();return 1}}
              if(typeof cur!=='undefined'&&cur!=='home'){go('home');return 1}
            }catch(e){}return 0})()
        """.trimIndent()
        web.evaluateJavascript(js) { r -> if (r != "1") finish() }
    }
}
