package com.mohammed.siraj

import android.content.Context
import android.webkit.JavascriptInterface

/** Exposed to index.html as window.SirajBridge */
class Bridge(private val ctx: Context, private val onAskPermission: () -> Unit = {}) {
    @JavascriptInterface
    fun sync(json: String) {
        Store.save(ctx, json)
        Widgets.updateAll(ctx)
        Scheduler.schedule(ctx)
    }

    @JavascriptInterface
    fun takeTaps(): Int = Store.takeTaps(ctx)

    // ---- notifications ----
    @JavascriptInterface
    fun notify(tag: String, title: String, body: String) {
        val ch = if (tag.startsWith("pr_")) Notifs.CH_PRAYER else Notifs.CH_GENERAL
        Notifs.show(ctx, tag, title, body, ch)
    }

    @JavascriptInterface
    fun hasPermission(): Boolean = Notifs.enabled(ctx)

    @JavascriptInterface
    fun requestPermission() = onAskPermission()

    @JavascriptInterface
    fun setAlarms(json: String) = Notifs.setAlarms(ctx, json)
}
