package com.mohammed.siraj

import android.content.Context
import android.webkit.JavascriptInterface

/** Exposed to index.html as window.SirajBridge */
class Bridge(private val ctx: Context) {
    @JavascriptInterface
    fun sync(json: String) {
        Store.save(ctx, json)
        Widgets.updateAll(ctx)
        Scheduler.schedule(ctx)
    }

    @JavascriptInterface
    fun takeTaps(): Int = Store.takeTaps(ctx)
}
