package com.mohammed.siraj

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate

/** Shared state between the WebView app and the home-screen widgets. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("siraj", Context.MODE_PRIVATE)

    fun save(c: Context, json: String) {
        p(c).edit().putString("snap", json).putString("snapDay", LocalDate.now().toString()).apply()
    }

    fun snap(c: Context): JSONObject =
        try { JSONObject(p(c).getString("snap", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun snapDay(c: Context): String = p(c).getString("snapDay", "") ?: ""

    fun taps(c: Context): Int = p(c).getInt("taps", 0)

    fun addTap(c: Context) { p(c).edit().putInt("taps", taps(c) + 1).apply() }

    fun takeTaps(c: Context): Int {
        val t = taps(c)
        p(c).edit().putInt("taps", 0).apply()
        return t
    }
}
