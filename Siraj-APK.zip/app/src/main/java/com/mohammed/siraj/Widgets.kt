package com.mohammed.siraj

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

open class BaseWidget(private val kind: String) : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, Widgets.build(ctx, kind))
        Scheduler.schedule(ctx)
    }
    override fun onEnabled(ctx: Context) { Scheduler.schedule(ctx) }
}

class PrayerWidget : BaseWidget("prayer")
class RamadanWidget : BaseWidget("ramadan")
class HijriWidget : BaseWidget("hijri")
class TasbeehWidget : BaseWidget("tasbeeh")
class DuaWidget : BaseWidget("dua")
class AyahWidget : BaseWidget("ayah")
class TasksWidget : BaseWidget("tasks")

class TapReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Store.addTap(ctx)
        Widgets.updateAll(ctx)
    }
}

class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Widgets.updateAll(ctx)
        Scheduler.schedule(ctx)
        Notifs.reschedule(ctx)
    }
}

object Scheduler {
    /** Wake up at the next prayer time or midnight (whichever is first) to refresh widgets. */
    fun schedule(ctx: Context) {
        try {
            val s = Store.snap(ctx)
            val n = Prayer.next(s.optDouble("lat", 30.0444), s.optDouble("lng", 31.2357))
            val now = ZonedDateTime.now()
            val midnight = now.toLocalDate().plusDays(1).atStartOfDay(now.zone).toInstant().toEpochMilli() + 5000
            val at = minOf(n.atMillis + 2000, midnight)
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 77, Intent(ctx, RefreshReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC, at, pi)
        } catch (e: Exception) { }
    }
}

object Widgets {
    private const val DEFAULT = "#0F6B4F"

    private val DUAS = arrayOf(
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
        "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي",
        "رَبِّ إِنِّي لِمَا أَنزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ",
        "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي",
        "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ",
        "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ"
    )

    private val KINDS: List<Pair<String, Class<*>>> = listOf(
        "prayer" to PrayerWidget::class.java,
        "ramadan" to RamadanWidget::class.java,
        "hijri" to HijriWidget::class.java,
        "tasbeeh" to TasbeehWidget::class.java,
        "dua" to DuaWidget::class.java,
        "ayah" to AyahWidget::class.java,
        "tasks" to TasksWidget::class.java
    )

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        for ((k, cls) in KINDS) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isEmpty()) continue
            val rv = build(ctx, k)
            for (id in ids) mgr.updateAppWidget(id, rv)
        }
    }

    private fun openIntent(ctx: Context, kind: String, page: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("go", page)
            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            ctx, kind.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun RemoteViews.text(id: Int, s: String?, sp: Float? = null) {
        if (s.isNullOrEmpty()) { setViewVisibility(id, View.GONE); return }
        setViewVisibility(id, View.VISIBLE)
        setTextViewText(id, s)
        if (sp != null) setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, sp)
    }

    fun build(ctx: Context, kind: String): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.w_card)
        val snap = Store.snap(ctx)
        val lat = snap.optDouble("lat", 30.0444)
        val lng = snap.optDouble("lng", 31.2357)

        val hex = snap.optJSONObject("wc")?.optString(kind, "")?.takeIf { it.isNotEmpty() } ?: DEFAULT
        val color = try { Color.parseColor(hex) } catch (e: Exception) { Color.parseColor(DEFAULT) }
        rv.setInt(R.id.bg, "setColorFilter", color)

        rv.setViewVisibility(R.id.chrono, View.GONE)
        rv.setViewVisibility(R.id.progress, View.GONE)
        rv.setViewVisibility(R.id.open, View.GONE)

        val today = LocalDate.now()
        var page = "home"

        when (kind) {
            "prayer" -> {
                page = "prayer"
                val n = Prayer.next(lat, lng)
                rv.text(R.id.title, "الصلاة القادمة", 13f)
                rv.text(R.id.big, n.name, 30f)
                rv.text(R.id.sub, Prayer.fmt(n.hours), 18f)
                rv.text(R.id.extra, null)
                rv.setViewVisibility(R.id.chrono, View.VISIBLE)
                val base = SystemClock.elapsedRealtime() + (n.atMillis - System.currentTimeMillis())
                rv.setChronometerCountDown(R.id.chrono, true)
                rv.setChronometer(R.id.chrono, base, null, true)
            }
            "ramadan" -> {
                page = "ramadan"
                val r = Hijri.ramadan(today)
                val h = Hijri.of(today)
                rv.text(R.id.title, "🌙 عداد رمضان", 13f)
                rv.text(R.id.big, Prayer.ar(r.daysLeft.toString()), 46f)
                if (r.inR) {
                    rv.text(R.id.sub, "رمضان — اليوم ${Prayer.ar(r.day.toString())} · يوم على العيد", 14f)
                    val p = Prayer.times(today, ZonedDateTime.now().offset.totalSeconds / 3600.0, lat, lng)
                    rv.text(R.id.extra, "الإمساك ${Prayer.fmt(p[0])} · الإفطار ${Prayer.fmt(p[4])}", 12f)
                } else {
                    rv.text(R.id.sub, "يوم على رمضان", 14f)
                    rv.text(R.id.extra, "${Prayer.ar(h.day.toString())} ${Hijri.MONTHS[h.month - 1]} ${Prayer.ar(h.year.toString())}", 12f)
                }
            }
            "hijri" -> {
                page = "cal"
                val h = Hijri.of(today)
                rv.text(R.id.title, Hijri.DAYS[today.dayOfWeek.value - 1], 13f)
                rv.text(R.id.big, Prayer.ar(h.day.toString()), 54f)
                rv.text(R.id.sub, "${Hijri.MONTHS[h.month - 1]} ${Prayer.ar(h.year.toString())}", 18f)
                rv.text(R.id.extra, Prayer.ar(today.format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("ar")))), 12f)
            }
            "tasbeeh" -> {
                page = "tasbeeh"
                val c = snap.optInt("tc", 0) + Store.taps(ctx)
                rv.text(R.id.title, snap.optString("tn", "سبحان الله"), 14f)
                rv.text(R.id.big, Prayer.ar(c.toString()), 54f)
                rv.text(R.id.sub, null)
                rv.text(R.id.extra, "اضغط للتسبيح", 12f)
                rv.setViewVisibility(R.id.open, View.VISIBLE)
                val tap = PendingIntent.getBroadcast(
                    ctx, 4242, Intent(ctx, TapReceiver::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                rv.setOnClickPendingIntent(R.id.root, tap)
                rv.setOnClickPendingIntent(R.id.open, openIntent(ctx, kind, page))
                return rv
            }
            "dua" -> {
                page = "adhkar"
                rv.text(R.id.title, "دعاء اليوم", 13f)
                rv.text(R.id.big, DUAS[today.dayOfMonth % 6], 18f)
                rv.text(R.id.sub, null)
                rv.text(R.id.extra, null)
            }
            "ayah" -> {
                val a = snap.optJSONObject("ay")
                rv.text(R.id.title, "آية اليوم", 13f)
                if (a != null) {
                    rv.text(R.id.big, a.optString("t"), 18f)
                    rv.text(R.id.sub, a.optString("s"), 13f)
                    rv.text(R.id.extra, if (Store.snapDay(ctx) == today.toString()) null else "افتح التطبيق لتجديد آية اليوم", 11f)
                } else {
                    rv.text(R.id.big, "رَبِّ إِنِّي لِمَا أَنزَلْتَ إِلَيَّ مِنْ خَيْرٍ فَقِيرٌ", 18f)
                    rv.text(R.id.sub, "سورة القصص · ${Prayer.ar("24")}", 13f)
                    rv.text(R.id.extra, "افتح التطبيق لتظهر آية مختلفة كل يوم", 11f)
                }
            }
            "tasks" -> {
                page = "tasks"
                val d = snap.optInt("td", 0)
                val t = snap.optInt("tt", 0)
                rv.text(R.id.title, "المهام", 13f)
                rv.text(R.id.big, Prayer.ar("$d/$t"), 38f)
                rv.text(R.id.sub, null)
                rv.text(R.id.extra, null)
                rv.setViewVisibility(R.id.progress, View.VISIBLE)
                rv.setProgressBar(R.id.progress, 100, if (t > 0) d * 100 / t else 0, false)
            }
        }
        rv.setOnClickPendingIntent(R.id.root, openIntent(ctx, kind, page))
        return rv
    }
}
