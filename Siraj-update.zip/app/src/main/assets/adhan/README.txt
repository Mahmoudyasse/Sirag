ضع هنا ملفات الأذان: makkah_mulla.mp3 makkah_2.mp3 madinah.mp3 egypt_tobar.mp3 egypt_refaat.mp3 egypt_basit.mp3 egypt_azhar.mp3 aqsa.mp3 afasy.mp3
