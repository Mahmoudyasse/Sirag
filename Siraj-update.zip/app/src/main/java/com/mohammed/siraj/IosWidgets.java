package com.mohammed.siraj;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.*;
import android.graphics.*;
import android.os.SystemClock;
import android.widget.RemoteViews;
import org.json.JSONObject;

/** ويدجات بستايل آيفون: Island / Liquid Glass / Colors (6 ثيمات) / عداد رمضان (مربعات يمين شفافة وشمال ملوّنة) */
public class IosWidgets {
    static final int[][] TH = {{0xFF7C3AED, 0xFFEC4899}, {0xFF0EA5E9, 0xFF22D3EE}, {0xFFF97316, 0xFFFACC15}, {0xFF10B981, 0xFF84CC16}, {0xFF1F2937, 0xFF4B5563}, {0xFFBE123C, 0xFFFB7185}};

    static JSONObject cfg(Context c) {
        try { return new JSONObject(c.getSharedPreferences("siraj_w", 0).getString("cfg", "{}")); } catch (Exception e) { return new JSONObject(); }
    }
    static int col(String s, int d) { try { return Color.parseColor(s); } catch (Exception e) { return d; } }

    static Bitmap bg(int c1, int c2, boolean glass) {
        int w = 560, h = 280; Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); RectF r = new RectF(0, 0, w, h); float rad = glass ? 90 : 120;
        p.setShader(new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP)); cv.drawRoundRect(r, rad, rad, p);
        if (glass) { // لمعة الزجاج السائل
            p.setShader(new LinearGradient(0, 0, 0, h * .55f, 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)); cv.drawRoundRect(r, rad, rad, p);
            p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(0x66FFFFFF); cv.drawRoundRect(new RectF(2, 2, w - 2, h - 2), rad, rad, p);
        }
        return b;
    }
    static Bitmap box(int color) {
        Bitmap b = Bitmap.createBitmap(160, 200, Bitmap.Config.ARGB_8888); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(color);
        new Canvas(b).drawRoundRect(new RectF(0, 0, 160, 200), 44, 44, p); return b;
    }
    static PendingIntent open(Context c) {
        return PendingIntent.getActivity(c, 0, c.getPackageManager().getLaunchIntentForPackage(c.getPackageName()), PendingIntent.FLAG_IMMUTABLE);
    }

    static RemoteViews card(Context c, String kind) {
        JSONObject f = cfg(c); RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.ios_w);
        int t = f.optInt("th", 0) % TH.length, a = TH[t][0], b2 = TH[t][1], tx = Color.WHITE;
        if (kind.equals("island")) { a = 0xFF000000; b2 = 0xFF111111; }
        JSONObject wc = f.optJSONObject("wc");
        if (wc != null && wc.has(kind)) { a = col(wc.optString(kind), a); b2 = a; } // لون مخصّص لكل ويدجت
        if (kind.equals("liquid")) { a = (a & 0x00FFFFFF) | 0xCC000000; b2 = (b2 & 0x00FFFFFF) | 0x88000000; }
        v.setImageViewBitmap(R.id.bg, bg(a, b2, kind.equals("liquid")));
        v.setTextColor(R.id.t1, tx); v.setTextColor(R.id.t2, tx); v.setTextColor(R.id.t3, tx); v.setTextColor(R.id.cd, tx);
        v.setTextViewText(R.id.t1, "الصلاة القادمة"); v.setTextViewText(R.id.t2, SirajMedia.nextName.isEmpty() ? "سراج" : SirajMedia.nextName);
        long left = SirajMedia.nextMs - System.currentTimeMillis();
        if (left > 0) { v.setChronometer(R.id.cd, SystemClock.elapsedRealtime() + left, null, true); if (android.os.Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.cd, true); }
        v.setOnClickPendingIntent(R.id.root, open(c)); return v;
    }

    static void ramadan(Context c, AppWidgetManager m, int[] ids) {
        JSONObject f = cfg(c); long s = Math.max(0, (long) f.optDouble("ram", System.currentTimeMillis()) - System.currentTimeMillis()) / 1000;
        int l = col(f.optString("l"), 0xFF2FD69A), lt = col(f.optString("lt"), 0xFF06201A), rt = col(f.optString("rt"), Color.WHITE);
        int bgc = col(f.optString("bg"), 0xFF0F8A5F), bg2 = col(f.optString("bg2"), 0xFF06201A);
        int r = ((int) (f.optDouble("ro", .16) * 255) << 24) | (col(f.optString("r"), Color.WHITE) & 0xFFFFFF);
        long[] n = {s / 86400, s % 86400 / 3600, s % 3600 / 60, s % 60};
        int[] num = {R.id.n1, R.id.n2, R.id.n3, R.id.n4}, bgs = {R.id.b1, R.id.b2, R.id.b3, R.id.b4};
        String[] lab = {"يوم", "ساعة", "دقيقة", "ثانية"};
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.ios_ram);
            v.setImageViewBitmap(R.id.bg, bg(bgc, bg2, false));
            v.setTextViewText(R.id.title, f.optBoolean("inR") ? "باقي على العيد" : "باقي على رمضان");
            for (int i = 0; i < 4; i++) {
                boolean left = i >= 2; // يمين = شفاف، شمال = لون مميز
                v.setImageViewBitmap(bgs[i], box(left ? l : r));
                v.setTextViewText(num[i], String.format("%02d\n%s", n[i], lab[i]));
                v.setTextColor(num[i], left ? lt : rt);
            }
            v.setOnClickPendingIntent(R.id.root, open(c)); m.updateAppWidget(id, v);
        }
    }
    static void updateRamadan(Context c) { AppWidgetManager m = AppWidgetManager.getInstance(c); ramadan(c, m, m.getAppWidgetIds(new ComponentName(c, Ramadan.class))); }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        Class<?>[] cl = {Island.class, Liquid.class, Colors.class};
        String[] k = {"island", "liquid", "colors"};
        for (int i = 0; i < 3; i++) for (int id : m.getAppWidgetIds(new ComponentName(c, cl[i]))) m.updateAppWidget(id, card(c, k[i]));
        updateRamadan(c);
    }

    public static class Island extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int i : ids) m.updateAppWidget(i, card(c, "island")); } }
    public static class Liquid extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int i : ids) m.updateAppWidget(i, card(c, "liquid")); } }
    public static class Colors extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int i : ids) m.updateAppWidget(i, card(c, "colors")); } }
    public static class Ramadan extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { ramadan(c, m, ids); } }
}
