package com.mohammed.siraj;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

/** يربط الجسر تلقائيًا بأي WebView في التطبيق، من غير تعديل MainActivity */
public class SirajApp extends Application implements Application.ActivityLifecycleCallbacks {
    boolean done = false;
    @Override public void onCreate() { super.onCreate(); registerActivityLifecycleCallbacks(this); }

    static WebView find(View v) {
        if (v instanceof WebView) return (WebView) v;
        if (v instanceof ViewGroup) { ViewGroup g = (ViewGroup) v; for (int i = 0; i < g.getChildCount(); i++) { WebView w = find(g.getChildAt(i)); if (w != null) return w; } }
        return null;
    }
    @Override public void onActivityResumed(final Activity a) {
        if (done) return;
        a.getWindow().getDecorView().post(new Runnable() { public void run() {
            WebView w = find(a.getWindow().getDecorView());
            if (w != null && !done) { done = true; w.addJavascriptInterface(new SirajMedia(a, w), "SirajMedia"); w.reload(); }
        } });
    }
    public void onActivityCreated(Activity a, Bundle b) {} public void onActivityStarted(Activity a) {} public void onActivityPaused(Activity a) {}
    public void onActivityStopped(Activity a) {} public void onActivitySaveInstanceState(Activity a, Bundle b) {} public void onActivityDestroyed(Activity a) {}
}
