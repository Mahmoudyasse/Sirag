package com.mohammed.siraj;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** يشغّل الأذان المختار وقت الصلاة حتى لو التطبيق مقفول */
public class AdhanService extends Service {
    static final String A_STOP = "siraj.adhan.stop";
    private MediaPlayer mp;
    private boolean done = false;
    private final Handler h = new Handler(Looper.getMainLooper());

    public static void start(Context c, String name) {
        Intent i = new Intent(c, AdhanService.class).putExtra("name", name == null ? "" : name);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception e) { }
    }

    static JSONObject cfg(Context c) {
        try { return new JSONObject(c.getSharedPreferences("siraj_w", 0).getString("adhan_cfg", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    /** تنزيل الأذان المختار (لو رابط إنترنت) مرة واحدة ليعمل بدون نت */
    public static void prefetch(final Context ctx, String json) {
        try {
            final String url = new JSONObject(json).optString("url", "");
            if (!url.startsWith("http")) return;
            final Context c = ctx.getApplicationContext();
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        File out = new File(c.getFilesDir(), "adhan.bin");
                        File tmp = new File(c.getFilesDir(), "adhan.tmp");
                        android.content.SharedPreferences sp = c.getSharedPreferences("siraj_w", 0);
                        if (sp.getString("adhan_url", "").equals(url) && out.exists() && out.length() > 1000) return;
                        String cur = url;
                        HttpURLConnection h = null;
                        for (int k = 0; k < 6; k++) {
                            h = (HttpURLConnection) new URL(cur).openConnection();
                            h.setConnectTimeout(20000); h.setReadTimeout(60000); h.setInstanceFollowRedirects(false);
                            h.connect();
                            int code = h.getResponseCode();
                            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                                String loc = h.getHeaderField("Location");
                                h.disconnect();
                                if (loc == null) return;
                                cur = new URL(new URL(cur), loc).toString();
                                h = null;
                                continue;
                            }
                            break;
                        }
                        if (h == null || h.getResponseCode() != 200) return;
                        InputStream in = h.getInputStream();
                        FileOutputStream o = new FileOutputStream(tmp);
                        byte[] b = new byte[16384]; int n;
                        while ((n = in.read(b)) > 0) o.write(b, 0, n);
                        o.close(); in.close();
                        if (tmp.length() > 1000) { out.delete(); if (tmp.renameTo(out)) sp.edit().putString("adhan_url", url).apply(); }
                    } catch (Exception e) { }
                }
            }).start();
        } catch (Exception e) { }
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && A_STOP.equals(i.getAction())) { finish(); return START_NOT_STICKY; }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("siraj_adhan", "الأذان", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 31, new Intent(this, AdhanService.class).setAction(A_STOP), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "siraj_adhan") : new Notification.Builder(this);
        String name = i == null ? "" : i.getStringExtra("name");
        b.setSmallIcon(R.drawable.ic_notif).setContentTitle("الأذان" + (name == null || name.length() == 0 ? "" : " — " + name))
                .setContentText("اضغط لإيقاف الأذان").setOngoing(true).setContentIntent(stop)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف الأذان", stop).build());
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(5, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(5, b.build());
        } catch (Exception e) { finish(); return START_NOT_STICKY; }
        h.postDelayed(new Runnable() { @Override public void run() { finish(); } }, 6 * 60 * 1000L);
        play(name == null ? "" : name);
        return START_NOT_STICKY;
    }

    private void play(String name) {
        release();
        JSONObject c = cfg(this);
        float vol = (float) c.optDouble("vol", 1.0);
        String url = c.optString("url", "");
        String fj = c.optString("fj", "");
        if ("الفجر".equals(name) && fj.length() > 0) url = fj;
        File f = new File(getFilesDir(), "adhan.bin");
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            boolean set = false;
            if (url.length() > 0 && !url.startsWith("http")) {
                try {
                    AssetFileDescriptor fd = getAssets().openFd(url);
                    mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
                    fd.close();
                    set = true;
                } catch (Exception e) { set = false; }
            }
            if (!set && url.startsWith("http") && f.exists() && f.length() > 1000) { mp.setDataSource(f.getAbsolutePath()); set = true; }
            if (!set) {
                try {
                    AssetFileDescriptor fd = getAssets().openFd("adhan/adhan13.mp3");
                    mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
                    fd.close();
                    set = true;
                } catch (Exception e) { mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)); }
            }
            mp.setVolume(vol, vol);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { @Override public void onCompletion(MediaPlayer m) { finish(); } });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() { @Override public boolean onError(MediaPlayer m, int w, int e) { finish(); return true; } });
            mp.prepare();
            mp.start();
        } catch (Exception e) { finish(); }
    }

    private void release() { try { if (mp != null) mp.release(); } catch (Exception e) { } mp = null; }

    private void finish() {
        if (done) return;
        done = true;
        release();
        try { stopForeground(true); } catch (Exception e) { }
        stopSelf();
    }

    @Override public void onDestroy() { release(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
