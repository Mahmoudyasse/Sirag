package com.mohammed.siraj;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

public class SirajReceivers {
    /** أزرار الإشعار الدائم: prev / toggle / next */
    public static class Media extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction() == null ? "" : i.getAction();
            SirajMedia.js("window.__sirajMedia&&__sirajMedia('" + a.replace("siraj.media.", "") + "')");
        }
    }

    static void show(Context c, String title, String body, boolean sal) { show(c, title, body, sal, ""); }

    static String prName(String k) {
        if (k.equals("fajr")) return "الفجر"; if (k.equals("dhuhr")) return "الظهر"; if (k.equals("asr")) return "العصر";
        if (k.equals("maghrib")) return "المغرب"; return "العشاء";
    }

    /** chan: "" عادي | "pr_fajr".."pr_isha" تنبيه قبل/بعد الصلاة بصوت خاص بكل صلاة */
    static void show(Context c, String title, String body, boolean sal, String chan) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        String ch = sal ? "siraj_salawat" : "siraj_alerts";
        if (chan != null && chan.startsWith("pr_")) {
            ch = "siraj_" + chan;
            if (Build.VERSION.SDK_INT >= 26) {
                String k = chan.substring(3);
                NotificationChannel pc = new NotificationChannel(ch, "تنبيه الصلاة — " + prName(k), NotificationManager.IMPORTANCE_HIGH);
                int raw = c.getResources().getIdentifier("remind_" + k, "raw", c.getPackageName());
                if (raw != 0) pc.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + raw),
                        new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                pc.enableVibration(true);
                nm.createNotificationChannel(pc);
            }
        } else if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(ch, sal ? "الصلاة على النبي" : "تذكيرات سراج", NotificationManager.IMPORTANCE_HIGH);
            int raw = c.getResources().getIdentifier("salawat", "raw", c.getPackageName());
            if (sal && raw != 0) nc.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + raw),
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            nm.createNotificationChannel(nc);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, ch) : new Notification.Builder(c);
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        b.setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(body).setAutoCancel(true)
         .setContentIntent(PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_IMMUTABLE));
        nm.notify((int) (System.currentTimeMillis() % 100000) + 100, b.build());
    }

    public static class Notif extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            String key = i.getStringExtra("k");
            if ("adhan".equals(key)) {
                org.json.JSONObject cfg;
                try { cfg = new org.json.JSONObject(c.getSharedPreferences("siraj_w", 0).getString("adhan_cfg", "{}")); } catch (Exception e) { cfg = new org.json.JSONObject(); }
                if (cfg.has("on") && cfg.optInt("on", 1) == 0) return;
                show(c, i.getStringExtra("t"), i.getStringExtra("b"), false, "");
                AdhanService.start(c, i.getStringExtra("n"));
                IosWidgets.updateAll(c);
                return;
            }
            show(c, i.getStringExtra("t"), i.getStringExtra("b"), i.getBooleanExtra("s", false), i.getStringExtra("c"));
        }
    }

    /** بعد إعادة تشغيل الجهاز: نعيد جدولة الأذان والتنبيهات */
    public static class Boot extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            String[] keys = {"adhan", "alerts", "prrem"};
            for (String k : keys) {
                try { SirajMedia.doSchedule(c, k, new org.json.JSONArray(c.getSharedPreferences("siraj_s", 0).getString("arr_" + k, "[]"))); } catch (Exception ignored) { }
            }
        }
    }
}
