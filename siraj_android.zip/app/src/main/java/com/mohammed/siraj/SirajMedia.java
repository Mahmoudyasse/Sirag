package com.mohammed.siraj;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

/** جسر الجافاسكربت: addJavascriptInterface(new SirajMedia(this, webView), "SirajMedia") */
public class SirajMedia {
    static WebView web;
    static String title = "", reader = "", nextName = "";
    static boolean playing = false, hasMedia = false;
    static long nextMs = 0;
    final Context ctx;

    public SirajMedia(Context c, WebView w) {
        ctx = c.getApplicationContext();
        web = w;
        Intent i = new Intent(ctx, SirajService.class);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    static void js(final String code) {
        final WebView w = web;
        if (w != null) w.post(new Runnable() { public void run() { w.evaluateJavascript(code, null); } });
    }

    static void refresh() { SirajService s = SirajService.instance; if (s != null) s.refresh(); }

    @JavascriptInterface public void update(String t, String r, boolean p) { title = t; reader = r; playing = p; hasMedia = true; refresh(); MoreWidgets.updateAll(ctx); }
    @JavascriptInterface public void setNext(String n, double ms) { nextName = n; nextMs = (long) ms; refresh(); IosWidgets.updateAll(ctx); }
    @JavascriptInterface public void setWidget(String json) {
        ctx.getSharedPreferences("siraj_w", 0).edit().putString("cfg", json).apply();
        IosWidgets.updateAll(ctx);
    }

    /** إشعار فيه زر "إيقاف الأذان" طول ما الأذان شغال */
    @JavascriptInterface public void adhan(boolean on) {
        android.app.NotificationManager nm = (android.app.NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (!on) { nm.cancel(2); return; }
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new android.app.NotificationChannel("siraj_adhan", "الأذان", android.app.NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getBroadcast(ctx, 77, new Intent(ctx, SirajReceivers.Media.class).setAction("siraj.media.stopadhan"), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(ctx, 0, ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName()), PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(ctx, "siraj_adhan") : new android.app.Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_notif).setContentTitle("الأذان").setContentText("اضغط لإيقاف الأذان").setOngoing(true).setContentIntent(open)
         .addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(ctx, android.R.drawable.ic_media_pause), "إيقاف الأذان", stop).build());
        nm.notify(2, b.build());
    }

    @JavascriptInterface public void scheduleKey(String key, String json) { try { doSchedule(ctx, key, new JSONArray(json)); } catch (Exception ignored) {} }
    @JavascriptInterface public void setExtra(String json) { ctx.getSharedPreferences("siraj_w", 0).edit().putString("extra", json).apply(); MoreWidgets.updateAll(ctx); }
    @JavascriptInterface public void setAdhan(String json) { ctx.getSharedPreferences("siraj_w", 0).edit().putString("adhan_cfg", json).apply(); AdhanService.prefetch(ctx, json); }
    @JavascriptInterface public void battery() {
        try { ctx.startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:" + ctx.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { try { ctx.startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) {} }
    }

    @JavascriptInterface public void schedule(String json) { try { doSchedule(ctx, "alerts", new JSONArray(json)); } catch (Exception ignored) {} }

    static void doSchedule(Context ctx, String key, JSONArray a) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences sp = ctx.getSharedPreferences("siraj_s", 0);
            sp.edit().putString("arr_" + key, a.toString()).apply();
            for (String id : sp.getStringSet("ids_" + key, new HashSet<String>())) am.cancel(pi(ctx, id, "", "", false, "", "", "", PendingIntent.FLAG_UPDATE_CURRENT));
            Set<String> ids = new HashSet<String>();
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String id = key + "_" + o.getString("id");
                PendingIntent p = pi(ctx, id, o.optString("title", "سراج"), o.optString("body"), o.optInt("sal") == 1, o.optString("c", ""), key, o.optString("n", ""), PendingIntent.FLAG_UPDATE_CURRENT);
                long t = (long) o.getDouble("t");
                if (t < System.currentTimeMillis()) continue;
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p);
                ids.add(id);
            }
            sp.edit().putStringSet("ids_" + key, ids).apply();
        } catch (Exception ignored) {}
    }

    static PendingIntent pi(Context ctx, String id, String t, String b, boolean sal, String ch, String key, String name, int flag) {
        Intent i = new Intent(ctx, SirajReceivers.Notif.class).putExtra("t", t).putExtra("b", b).putExtra("s", sal).putExtra("c", ch).putExtra("k", key).putExtra("n", name);
        i.setAction("siraj.alarm." + id);
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i, flag | PendingIntent.FLAG_IMMUTABLE);
    }
}
