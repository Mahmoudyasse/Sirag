package com.mohammed.siraj;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** باقي ويدجات التطبيق على الشاشة الرئيسية: هجري، سبحة، دعاء، مهام، آية، مشغّل القرآن، حلقة، Aurora، Mono */
public class MoreWidgets {
    static final int EM1 = 0xFF064E3B, EM2 = 0xFF047857;

    static JSONObject json(Context c, String key) {
        try { return new JSONObject(c.getSharedPreferences("siraj_w", 0).getString(key, "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static int[] pair(Context c, String kind) {
        int a = EM1, b = EM2;
        JSONObject wc = IosWidgets.cfg(c).optJSONObject("wc");
        if (wc != null && wc.has(kind)) { a = IosWidgets.col(wc.optString(kind), a); b = a; }
        return new int[]{a, b};
    }

    static String ar(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { char ch = s.charAt(i); b.append(ch >= '0' && ch <= '9' ? (char) ('\u0660' + (ch - '0')) : ch); }
        return b.toString();
    }

    static RemoteViews txt(Context c, String kind, String t1, String t2, String t3, float size, PendingIntent click) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.ios_txt);
        int[] p = pair(c, kind);
        v.setImageViewBitmap(R.id.bg, IosWidgets.bg(p[0], p[1], false));
        v.setTextViewText(R.id.t1, t1); v.setTextViewText(R.id.t2, t2); v.setTextViewText(R.id.t3, t3);
        v.setTextViewTextSize(R.id.t2, TypedValue.COMPLEX_UNIT_SP, size);
        v.setTextColor(R.id.t1, Color.WHITE); v.setTextColor(R.id.t2, Color.WHITE); v.setTextColor(R.id.t3, 0xCCFFFFFF);
        v.setViewVisibility(R.id.t3, t3 == null || t3.length() == 0 ? View.GONE : View.VISIBLE);
        v.setOnClickPendingIntent(R.id.root, click);
        return v;
    }

    static PendingIntent media(Context c, String a) {
        return PendingIntent.getBroadcast(c, ("w" + a).hashCode(), new Intent(c, SirajReceivers.Media.class).setAction("siraj.media." + a), PendingIntent.FLAG_IMMUTABLE);
    }

    static RemoteViews hijri(Context c) {
        String hj = json(c, "extra").optString("hj", "");
        String g = ar(new SimpleDateFormat("EEEE d MMMM yyyy", new Locale("ar")).format(new Date()));
        return txt(c, "hijri", "التاريخ الهجري", hj.length() == 0 ? "افتح التطبيق" : hj, g, 22, IosWidgets.open(c));
    }

    static RemoteViews tasbeeh(Context c) {
        JSONObject s = json(c, "sync");
        int cnt = s.optInt("tc", 0) + c.getSharedPreferences("siraj_w", 0).getInt("taps", 0);
        Intent i = new Intent(c, Tap.class).setAction("siraj.tap");
        return txt(c, "tasbeeh", s.optString("tn", "سبحان الله"), ar(String.valueOf(cnt)), "اضغط للتسبيح", 46,
                PendingIntent.getBroadcast(c, 41, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
    }

    static RemoteViews dua(Context c) {
        JSONObject d = json(c, "extra").optJSONObject("dua");
        return txt(c, "dua", "دعاء اليوم", d == null ? "افتح التطبيق" : d.optString("t", ""), d == null ? "" : d.optString("s", ""), 17, IosWidgets.open(c));
    }

    static RemoteViews tasks(Context c) {
        JSONObject s = json(c, "sync");
        int d = s.optInt("td", 0), t = s.optInt("tt", 0);
        return txt(c, "tasks", "المهام", ar(d + " / " + t), t == 0 ? "لا توجد مهام" : (d >= t ? "أنجزت كل مهامك" : "متبقي " + ar(String.valueOf(t - d))), 40, IosWidgets.open(c));
    }

    static RemoteViews ayah(Context c) {
        JSONObject a = json(c, "sync").optJSONObject("ay");
        return txt(c, "ayah", "آية اليوم", a == null ? "افتح التطبيق" : a.optString("t", ""), a == null ? "" : a.optString("s", ""), 16, IosWidgets.open(c));
    }

    static RemoteViews player(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.ios_player);
        int[] p = pair(c, "player");
        v.setImageViewBitmap(R.id.bg, IosWidgets.bg(p[0], p[1], false));
        v.setTextViewText(R.id.t1, SirajMedia.hasMedia && SirajMedia.title.length() > 0 ? SirajMedia.title : "القرآن الكريم");
        v.setTextViewText(R.id.t2, SirajMedia.hasMedia && SirajMedia.reader.length() > 0 ? SirajMedia.reader : "اختر سورة من التطبيق");
        v.setImageViewResource(R.id.b_play, SirajMedia.playing ? R.drawable.ic_pause : R.drawable.ic_play);
        v.setOnClickPendingIntent(R.id.b_prev, media(c, "prev"));
        v.setOnClickPendingIntent(R.id.b_play, media(c, "toggle"));
        v.setOnClickPendingIntent(R.id.b_next, media(c, "next"));
        v.setOnClickPendingIntent(R.id.root, IosWidgets.open(c));
        return v;
    }

    static Bitmap ringBmp(float frac) {
        int s = 300;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(26); p.setStrokeCap(Paint.Cap.ROUND);
        RectF r = new RectF(26, 26, s - 26, s - 26);
        p.setColor(0x33FFFFFF); cv.drawArc(r, 0, 360, false, p);
        p.setColor(0xFFF2C66D); cv.drawArc(r, -90, 360f * Math.max(0.02f, Math.min(1f, frac)), false, p);
        return b;
    }

    static long prevPrayer(Context c, long next) {
        long best = 0, now = System.currentTimeMillis();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences("siraj_s", 0).getString("arr_adhan", "[]"));
            for (int i = 0; i < a.length(); i++) { long t = (long) a.getJSONObject(i).getDouble("t"); if (t <= now && t > best) best = t; }
        } catch (Exception ignored) { }
        return best > 0 ? best : next - 5L * 3600000L;
    }

    static RemoteViews ring(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.ios_ring);
        int[] p = pair(c, "ring");
        v.setImageViewBitmap(R.id.bg, IosWidgets.bg(p[0], p[1], false));
        long next = SirajMedia.nextMs, now = System.currentTimeMillis();
        float frac = 0;
        if (next > now) { long pv = prevPrayer(c, next); frac = (float) (now - pv) / (float) Math.max(1, next - pv); }
        v.setImageViewBitmap(R.id.ring, ringBmp(frac));
        v.setTextViewText(R.id.t2, SirajMedia.nextName.length() == 0 ? "سراج" : SirajMedia.nextName);
        if (next > now) { v.setChronometer(R.id.cd, SystemClock.elapsedRealtime() + (next - now), null, true); v.setChronometerCountDown(R.id.cd, true); }
        v.setOnClickPendingIntent(R.id.root, IosWidgets.open(c));
        return v;
    }

    static Bitmap aurora() {
        int w = 400, h = 200;
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF r = new RectF(0, 0, w, h);
        p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF0EA5E9, 0xFF8B5CF6, 0xFFEC4899}, null, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, 70, 70, p);
        p.setShader(new RadialGradient(90, 40, 220, 0x77FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, 70, 70, p);
        return b;
    }

    static Bitmap mono() {
        int w = 400, h = 200;
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFF4F4F5);
        new Canvas(b).drawRoundRect(new RectF(0, 0, w, h), 70, 70, p);
        return b;
    }

    static RemoteViews nextCard(Context c, Bitmap bmp, int tx) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.ios_w);
        v.setImageViewBitmap(R.id.bg, bmp);
        v.setTextColor(R.id.t1, tx); v.setTextColor(R.id.t2, tx); v.setTextColor(R.id.t3, tx); v.setTextColor(R.id.cd, tx);
        v.setTextViewText(R.id.t1, "الصلاة القادمة");
        v.setTextViewText(R.id.t2, SirajMedia.nextName.length() == 0 ? "سراج" : SirajMedia.nextName);
        long left = SirajMedia.nextMs - System.currentTimeMillis();
        if (left > 0) { v.setChronometer(R.id.cd, SystemClock.elapsedRealtime() + left, null, true); v.setChronometerCountDown(R.id.cd, true); }
        v.setOnClickPendingIntent(R.id.root, IosWidgets.open(c));
        return v;
    }

    static RemoteViews build(Context c, String kind) {
        if (kind.equals("hijri")) return hijri(c);
        if (kind.equals("tasbeeh")) return tasbeeh(c);
        if (kind.equals("dua")) return dua(c);
        if (kind.equals("tasks")) return tasks(c);
        if (kind.equals("ayah")) return ayah(c);
        if (kind.equals("player")) return player(c);
        if (kind.equals("ring")) return ring(c);
        if (kind.equals("aurora")) return nextCard(c, aurora(), Color.WHITE);
        return nextCard(c, mono(), 0xFF111111);
    }

    static final Class<?>[] CLS = {Hijri.class, Tasbeeh.class, Dua.class, Tasks.class, Ayah.class, Player.class, Ring.class, Aurora.class, Mono.class};
    static final String[] KINDS = {"hijri", "tasbeeh", "dua", "tasks", "ayah", "player", "ring", "aurora", "mono"};

    public static void updateAll(Context ctx) {
        try {
            Context c = ctx.getApplicationContext();
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            for (int k = 0; k < CLS.length; k++) {
                int[] ids = m.getAppWidgetIds(new ComponentName(c, CLS[k]));
                if (ids == null) continue;
                for (int id : ids) m.updateAppWidget(id, build(c, KINDS[k]));
            }
        } catch (Exception ignored) { }
    }

    static void one(Context c, AppWidgetManager m, int[] ids, String kind) { for (int id : ids) m.updateAppWidget(id, build(c, kind)); }

    public static class Tap extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            SharedPreferences sp = c.getSharedPreferences("siraj_w", 0);
            sp.edit().putInt("taps", sp.getInt("taps", 0) + 1).apply();
            updateAll(c);
        }
    }

    public static class Hijri extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "hijri"); } }
    public static class Tasbeeh extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "tasbeeh"); } }
    public static class Dua extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "dua"); } }
    public static class Tasks extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "tasks"); } }
    public static class Ayah extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "ayah"); } }
    public static class Player extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "player"); } }
    public static class Ring extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "ring"); } }
    public static class Aurora extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "aurora"); } }
    public static class Mono extends AppWidgetProvider { public void onUpdate(Context c, AppWidgetManager m, int[] ids) { one(c, m, ids, "mono"); } }
}
